#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <vector>

#define LED_PIN 48
#define DIR_PIN 7
#define STEP_PIN 15
#define SWITCH_PIN 1
#define ONE_ROTATION 3200

float steps_per_sec = 700;
int steps_mils = int(1000 / steps_per_sec);
std::vector<int> num_buffer = {};

String receivedMessage = "";

Adafruit_NeoPixel pixel(1, LED_PIN, NEO_GBR + NEO_KHZ800);

float current_deg = 0;
int current_pos = 0;

void setup() {
  Serial.begin(115200);

  Serial.println("ESP32 is ready!");

  pinMode(DIR_PIN, OUTPUT);
  pinMode(SWITCH_PIN, INPUT);
  pinMode(STEP_PIN, OUTPUT);
  
  pixel.begin();
}

void moveTo(float move_deg){
  int move_pos = int(ONE_ROTATION / (360 / move_deg));
  int total_move = move_pos - current_pos;
  if(total_move < 0){
    digitalWrite(DIR_PIN, HIGH);
  } else{
    digitalWrite(DIR_PIN, LOW);
  }

  for(int i = 0; i < abs(total_move); i++){
    delayMicroseconds(int(1000 * steps_mils / 2));
    digitalWrite(STEP_PIN, HIGH);
    delayMicroseconds(int(1000 * steps_mils / 2));
    digitalWrite(STEP_PIN, LOW);
  }

  current_deg = move_deg;
  current_pos = move_pos;
}

void loop() {
  bool switch_state = digitalRead(SWITCH_PIN);
  if (switch_state == HIGH){
    digitalWrite(DIR_PIN, HIGH);  
  } else {
    digitalWrite(DIR_PIN, LOW);
  }

  while(Serial.available()){
    char incomingChar = Serial.read();

    if(incomingChar == '\n'){
      Serial.println(receivedMessage);
      moveTo(receivedMessage.toFloat());
      

      receivedMessage = "";
    } else {
      receivedMessage += incomingChar;
    }
  }
  
  // put your main code here, to run repeatedly:
}